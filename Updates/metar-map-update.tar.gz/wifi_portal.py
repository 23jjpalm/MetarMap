#!/usr/bin/env python3
import html, json, os, subprocess, threading, time, urllib.request
from pathlib import Path
from flask import Flask, jsonify, redirect, request
BASE=Path('/opt/metar-map'); CONFIG=BASE/'config.json'; STATUS=BASE/'status.json'; COMMAND=BASE/'command.json'; VERSION=BASE/'VERSION'; UPDATER_CONFIG=Path('/etc/metar-map-updater.conf')
HOTSPOT='metar-map-setup'; SSID=os.environ.get('HOTSPOT_SSID','METAR-Map-Setup'); IP=os.environ.get('HOTSPOT_IP','192.168.4.1'); IFACE=os.environ.get('WIFI_INTERFACE','wlan0')
DEFAULT_MANIFEST_URL='https://raw.githubusercontent.com/23jjpalm/MetarMap/main/releases/manifest.json'
app=Flask(__name__)
def atomic(path,data):
 t=path.with_suffix(path.suffix+'.tmp'); t.write_text(json.dumps(data,indent=2)+'\n'); os.replace(t,path)
def read(path,default):
 try:return json.loads(path.read_text())
 except Exception:return default
def run(cmd,timeout=30):return subprocess.run(cmd,capture_output=True,text=True,check=False,timeout=timeout)
def send(action,**kw):atomic(COMMAND,{'action':action,'issued_epoch':time.time(),**kw})
def esc(v):return html.escape(str(v),quote=True)
def hotspot():
 try:return HOTSPOT in run(['nmcli','-t','-f','NAME','connection','show','--active']).stdout.splitlines()
 except Exception:return False
def wifi():
 try:return any(x.startswith('wlan') and ':connected' in x for x in run(['nmcli','-t','-f','DEVICE,STATE','device','status']).stdout.splitlines())
 except Exception:return False
def age(epoch):
 if not epoch:return 'Never'
 s=max(0,int(time.time()-float(epoch))); return f'{s} seconds ago' if s<60 else f'{s//60} minutes ago' if s<3600 else f'{s//3600} hours ago'
def installed_version():
 try:return VERSION.read_text().strip() or 'unknown'
 except Exception:return 'unknown'
def get_manifest_url():
 try:
  for raw in UPDATER_CONFIG.read_text().splitlines():
   line=raw.strip()
   if line and not line.startswith('#') and '=' in line:
    key,value=line.split('=',1)
    if key.strip()=='MANIFEST_URL' and value.strip():return value.strip()
 except Exception:pass
 return DEFAULT_MANIFEST_URL
def version_tuple(value):
 try:return tuple(int(part) for part in str(value).split('.'))
 except Exception:return None
def check_update_status():
 local=installed_version()
 try:
  url=get_manifest_url()
  req=urllib.request.Request(url,headers={'User-Agent':'JordanHomeMetarMapDashboard/1.1.2'})
  with urllib.request.urlopen(req,timeout=10) as response:
   manifest=json.loads(response.read(256000).decode('utf-8'))
  remote=str(manifest.get('version','')).strip()
  if not remote:raise RuntimeError('The hosted manifest does not contain a version number.')
  if local==remote:
   return {'ok':True,'status':'up_to_date','installed_version':local,'available_version':remote,'message':f'Up to date. Installed version: {local}.'}
  local_parts=version_tuple(local); remote_parts=version_tuple(remote)
  if local_parts and remote_parts and local_parts>remote_parts:
   return {'ok':True,'status':'hosted_release_older','installed_version':local,'available_version':remote,'message':f'This map is newer than the hosted release. Installed version: {local}. Hosted version: {remote}. Publish the latest manifest when testing is complete.'}
  return {'ok':True,'status':'update_available','installed_version':local,'available_version':remote,'message':f'Update available. Installed version: {local}. Available version: {remote}.'}
 except Exception as error:
  return {'ok':False,'status':'error','installed_version':local,'available_version':None,'message':f'Unable to check for updates: {error}'}
def networks():
 try: out=run(['nmcli','-t','-f','SSID','device','wifi','list','ifname',IFACE,'--rescan','auto'],15).stdout.splitlines()
 except Exception:return []
 seen=[]
 for x in out:
  x=x.replace(r'\:',':').replace(r'\\','\\').strip()
  if x and x!=SSID and x not in seen:seen.append(x)
 return sorted(seen,key=str.lower)
def connect(ssid,password):
 time.sleep(2); run(['nmcli','connection','down',HOTSPOT],15); time.sleep(1); cmd=['nmcli','device','wifi','connect',ssid,'ifname',IFACE];
 if password:cmd+=['password',password]
 run(cmd,45)
def layout(title,body,active):
 nav=''.join(f'<a class="{"active" if k==active else ""}" href="{u}">{n}</a>' for k,u,n in [('status','/','Status'),('settings','/settings','Map Settings'),('wifi','/wifi','Wi-Fi')])
 return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>
body{{font-family:Arial;margin:0;background:#eef2f5;color:#1d2730}}header{{background:#183447;color:white;padding:18px}}nav{{background:#244b63;padding:9px;display:flex;gap:8px}}nav a{{color:white;text-decoration:none;padding:9px;border-radius:8px}}nav a.active,nav a:hover{{background:#3d6f8d}}main{{max-width:930px;margin:20px auto;padding:0 14px}}.card{{background:white;padding:18px;border-radius:14px;margin:14px 0;box-shadow:0 4px 15px #0002}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}}.stat{{background:#f4f7f9;padding:12px;border-radius:10px}}.stat b{{display:block;font-size:13px;color:#60717d;margin-bottom:6px}}button{{border:0;border-radius:9px;padding:11px 14px;background:#1769aa;color:white;font-size:15px;cursor:pointer;margin:4px}}button.secondary{{background:#6b7c86}}button.warn{{background:#b45f06}}button.danger{{background:#b3261e}}input,select{{width:100%;box-sizing:border-box;padding:10px;border:1px solid #b6c0c7;border-radius:8px}}label{{display:block;font-weight:bold;margin:10px 0 5px}}table{{width:100%;border-collapse:collapse}}th,td{{padding:8px;border-bottom:1px solid #dde4e8;text-align:left}}.small{{font-size:13px;color:#61717c}}.network{{display:block;width:100%;text-align:left;background:#eaf2f7;color:#1d2730}}</style></head><body><header><h1>METAR Map Dashboard</h1></header><nav>{nav}</nav><main>{body}</main></body></html>'''
@app.get('/')
def home():
 s=read(STATUS,{})
 body=f'''<div class="card"><h2>System Status</h2><div class="grid"><div class="stat"><b>Version</b>{esc(s.get('version','unknown'))}</div><div class="stat"><b>Configured LEDs</b>{esc(s.get('led_count','?'))}</div><div class="stat"><b>Wi-Fi</b>{'Connected' if wifi() else 'Not connected'}</div><div class="stat"><b>Setup hotspot</b>{'Active' if hotspot() else 'Off'}</div><div class="stat"><b>Weather API</b>{esc(s.get('diagnostic_state','Unknown'))}</div><div class="stat"><b>Last weather update</b>{age(s.get('last_success_epoch'))}</div><div class="stat"><b>Display mode</b>{esc(s.get('mode_label','Unknown'))}</div><div class="stat"><b>Brightness</b>{esc(s.get('brightness_percent','?'))}%</div><div class="stat"><b>Reports loaded</b>{esc(s.get('report_count',0))}</div></div><p>{esc(s.get('last_error',''))}</p></div><div class="card"><h2>Controls</h2><form method="post" action="/action/refresh"><button>Refresh weather</button></form><form method="post" action="/action/test"><button>Test LEDs</button></form><button type="button" onclick="checkUpdates()">Check for updates</button><div id="update-result" class="small" style="margin:10px 4px"></div><form method="post" action="/action/restart"><button class="warn">Restart map software</button></form><form method="post" action="/action/hotspot"><button class="warn">Start Wi-Fi setup mode</button></form><form method="post" action="/action/reboot"><button class="danger">Restart device</button></form></div><script>async function checkUpdates(){{const result=document.getElementById('update-result');result.textContent='Checking for updates...';try{{const response=await fetch('/api/check-update',{{method:'POST'}});const data=await response.json();result.textContent=data.message;result.style.color=data.status==='update_available'?'#b45f06':data.status==='up_to_date'?'#18733c':data.status==='hosted_release_older'?'#1769aa':'#b3261e';}}catch(error){{result.textContent='Unable to check for updates: '+error;result.style.color='#b3261e';}}}}</script>'''
 return layout('Status',body,'status')
@app.route('/settings',methods=['GET','POST'])
def settings():
 c=read(CONFIG,{})
 led=c.get('led',{})
 old_n=max(1,min(300,int(led.get('count',22))))
 airports=(c.get('airports',[])+[None]*old_n)[:old_n]
 note=''
 if request.method=='POST':
  requested_n=int(request.form.get('led_count',old_n))
  new_n=max(1,min(300,requested_n))
  airports=[request.form.get(f'airport_{i}','').strip().upper() or None for i in range(1,min(old_n,new_n)+1)]
  if new_n>len(airports):airports.extend([None]*(new_n-len(airports)))
  c['airports']=airports[:new_n]
  c['default_mode']=request.form.get('default_mode','category')
  led['count']=new_n
  led['day_brightness_percent']=int(request.form.get('day',32))
  led['night_brightness_percent']=int(request.form.get('night',8))
  led['night_start']=request.form.get('start','22:00')
  led['night_end']=request.form.get('end','07:00')
  diag=int(request.form.get('diag',2))
  led['diagnostic_position']=diag if 0<=diag<=new_n else 0
  c['led']=led
  atomic(CONFIG,c)
  if new_n!=old_n:
   threading.Thread(target=lambda:(time.sleep(1),run(['systemctl','restart','metar-map.service'])),daemon=True).start()
   note='<p><b>Settings saved.</b> The map software is restarting to apply the new LED count.</p>'
  else:
   send('reload_config')
   note='<p><b>Settings saved.</b></p>'
  old_n=new_n
  airports=c['airports']
 n=old_n
 diag=int(led.get('diagnostic_position',2))
 rows=''.join(f'<tr><td>{i}</td><td><input name="airport_{i}" value="{esc(airports[i-1] or "")}" maxlength="5" onfocus="preview({i})" oninput="preview({i})"></td><td>{"Diagnostic LED" if i==diag else ""}</td><td><button type="button" class="secondary" onclick="preview({i})">Light LED</button></td></tr>' for i in range(1,n+1))
 opts=''.join(f'<option value="{m}" {"selected" if c.get("default_mode")==m else ""}>{label}</option>' for m,label in [('category','Flight Category'),('ceiling','Cloud Base'),('wind','Wind Speed')])
 dopts='<option value="0">Disabled</option>'+''.join(f'<option value="{i}" {"selected" if i==diag else ""}>LED {i}</option>' for i in range(1,n+1))
 body=f'''<div class="card"><h2>Map Settings</h2>{note}<form method="post"><div class="grid"><div><label>Number of LEDs</label><input type="number" min="1" max="300" name="led_count" value="{n}"><p class="small">Save once after changing this number. The map service restarts and the assignment table resizes.</p></div><div><label>Default mode</label><select name="default_mode">{opts}</select></div><div><label>Diagnostic LED</label><select name="diag">{dopts}</select></div><div><label>Day brightness %</label><input type="number" min="0" max="100" name="day" value="{esc(led.get('day_brightness_percent',32))}"></div><div><label>Night brightness %</label><input type="number" min="0" max="100" name="night" value="{esc(led.get('night_brightness_percent',8))}"></div><div><label>Night starts</label><input type="time" name="start" value="{esc(led.get('night_start','22:00'))}"></div><div><label>Night ends</label><input type="time" name="end" value="{esc(led.get('night_end','07:00'))}"></div></div><h3>Airport assignments</h3><p class="small">Selecting or typing in a field lights that physical LED white. Leave a field blank to keep the LED off.</p><table><tr><th>LED</th><th>Airport code</th><th>Reserved</th><th>Preview</th></tr>{rows}</table><button>Save settings</button><button type="button" class="secondary" onclick="test()">Test all LEDs</button></form></div><script>function preview(n){{fetch('/api/preview/'+n,{{method:'POST'}})}} function test(){{fetch('/api/test',{{method:'POST'}})}}</script>'''
 return layout('Settings',body,'settings')
@app.get('/wifi')
def wifi_page():
 buttons=''.join(f'<button type="button" class="network" onclick="pick({json.dumps(x)})">{esc(x)}</button>' for x in networks())
 body=f'''<div class="card"><h2>Wi-Fi Setup</h2>{buttons}<form method="post" action="/connect"><label>Wi-Fi name</label><input id="ssid" name="ssid" required><label>Password</label><input name="password" type="password"><button>Connect</button></form><p class="small">Setup mode address: http://{esc(IP)}</p></div><script>function pick(x){{document.getElementById('ssid').value=x}}</script>'''; return layout('Wi-Fi',body,'wifi')
@app.post('/connect')
def connect_route():threading.Thread(target=connect,args=(request.form.get('ssid','').strip(),request.form.get('password','')),daemon=True).start(); return redirect('/wifi')
@app.post('/api/preview/<int:n>')
def preview(n):send('preview_led',led=n); return jsonify(ok=True)
@app.post('/api/test')
def test():send('test_leds'); return jsonify(ok=True)
@app.post('/api/check-update')
def api_check_update():return jsonify(check_update_status())
@app.post('/action/<name>')
def action(name):
 if name=='refresh':send('refresh_weather')
 elif name=='test':send('test_leds')
 elif name=='restart':run(['systemctl','restart','metar-map.service'])
 elif name=='hotspot':run(['nmcli','connection','up',HOTSPOT])
 elif name=='reboot':threading.Thread(target=lambda:(time.sleep(1),run(['systemctl','reboot'])),daemon=True).start()
 return redirect('/')
@app.route('/<path:path>')
def fallback(path):return redirect('/wifi' if hotspot() else '/')
if __name__=='__main__':app.run(host='0.0.0.0',port=80)
