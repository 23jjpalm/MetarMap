#!/usr/bin/env python3
import functools
import hashlib
import hmac
import html
import json
import math
import os
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template_string, request, session, url_for

BASE = Path("/opt/metar-map")
CONFIG = BASE / "config.json"
STATUS = BASE / "status.json"
COMMAND = BASE / "command.json"
VERSION = BASE / "VERSION"
UPDATER_CONFIG = Path("/etc/metar-map-updater.conf")

HOTSPOT_CONNECTION = "metar-map-setup"
HOTSPOT_SSID = os.environ.get("HOTSPOT_SSID", "METAR-Map-Setup")
HOTSPOT_IP = os.environ.get("HOTSPOT_IP", "192.168.4.1")
WIFI_INTERFACE = os.environ.get("WIFI_INTERFACE", "wlan0")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "palmieri")
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/23jjpalm/MetarMap/main/Updates/manifest.json"

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "replace-this-development-key")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

STYLE = """
<style>
:root{font-family:Arial,sans-serif;color:#1d2730;background:#eef2f5}
body{margin:0;background:#eef2f5}
header{background:#183447;color:white;padding:18px 20px}
header h1{margin:0;font-size:24px}
header .badge{font-size:14px;font-weight:normal;opacity:.82}
nav{display:flex;gap:8px;flex-wrap:wrap;background:#244b63;padding:9px 14px}
nav a{color:white;text-decoration:none;padding:9px 12px;border-radius:8px}
nav a.active,nav a:hover{background:#3d6f8d}
main{max-width:980px;margin:20px auto;padding:0 14px 28px}
.card{background:white;border-radius:14px;padding:18px;margin:14px 0;box-shadow:0 4px 15px #0002}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(185px,1fr));gap:10px}
.stat{background:#f4f7f9;border-radius:10px;padding:12px}
.stat b{display:block;font-size:13px;color:#60717d;margin-bottom:6px}
button,.button{border:0;border-radius:9px;padding:11px 14px;background:#1769aa;color:white;font-size:15px;cursor:pointer;text-decoration:none;display:inline-block;margin:5px 5px 5px 0}
button.secondary,.button.secondary{background:#6b7c86}
button.warning,.button.warning{background:#b45f06}
button.danger,.button.danger{background:#b3261e}
input,select{width:100%;box-sizing:border-box;padding:10px;border:1px solid #b6c0c7;border-radius:8px;font-size:15px}
label{display:block;font-weight:bold;margin:10px 0 5px}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;border-bottom:1px solid #dde4e8;text-align:left;vertical-align:top}
.small{font-size:13px;color:#61717c}
.notice{background:#e7f3e8;border-radius:9px;padding:11px;margin:10px 0}
.error{background:#fde8e8;border-radius:9px;padding:11px;margin:10px 0}
.warning-box{background:#fff3dd;border-radius:9px;padding:11px;margin:10px 0}
.network{display:block;width:100%;text-align:left;background:#eaf2f7;color:#1d2730;margin:6px 0}
.actions{display:flex;flex-wrap:wrap}
.calc-output{background:#f4f7f9;border-radius:10px;padding:12px;min-height:24px;margin-top:10px}
.login-card{max-width:420px;margin:38px auto}
.inline-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px}
@media(max-width:620px){th:nth-child(3),td:nth-child(3){display:none}}
</style>
"""

def esc(value):
    return html.escape(str(value), quote=True)

def atomic_write(path, payload):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)

def read_json(path, fallback):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback

def run(command, timeout=30):
    return subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)

def send_command(action, **kwargs):
    atomic_write(COMMAND, {"action": action, "issued_epoch": time.time(), **kwargs})

def installed_version():
    try:
        return VERSION.read_text(encoding="utf-8").strip() or "unknown"
    except Exception:
        return "unknown"

def age_text(epoch):
    if not epoch:
        return "Never"
    seconds = max(0, int(time.time() - float(epoch)))
    if seconds < 60:
        return f"{seconds} seconds ago"
    if seconds < 3600:
        return f"{seconds // 60} minutes ago"
    return f"{seconds // 3600} hours ago"

def hotspot_active():
    try:
        result = run(["nmcli", "-t", "-f", "NAME", "connection", "show", "--active"])
        return HOTSPOT_CONNECTION in result.stdout.splitlines()
    except Exception:
        return False

def wifi_connected():
    try:
        result = run(["nmcli", "-t", "-f", "DEVICE,STATE", "device", "status"])
        return any(line.startswith("wlan") and ":connected" in line for line in result.stdout.splitlines())
    except Exception:
        return False

def list_networks():
    try:
        result = run(
            ["nmcli", "-t", "-f", "SSID", "device", "wifi", "list", "ifname", WIFI_INTERFACE, "--rescan", "auto"],
            timeout=15,
        )
    except Exception:
        return []
    networks = []
    for raw in result.stdout.splitlines():
        ssid = raw.replace(r"\:", ":").replace(r"\\", "\\").strip()
        if ssid and ssid != HOTSPOT_SSID and ssid not in networks:
            networks.append(ssid)
    return sorted(networks, key=str.lower)

def connect_worker(ssid, password):
    time.sleep(2)
    run(["nmcli", "connection", "down", HOTSPOT_CONNECTION], timeout=15)
    time.sleep(1)
    command = ["nmcli", "device", "wifi", "connect", ssid, "ifname", WIFI_INTERFACE]
    if password:
        command += ["password", password]
    run(command, timeout=45)

def get_manifest_url():
    try:
        for raw in UPDATER_CONFIG.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                if key.strip() == "MANIFEST_URL" and value.strip():
                    return value.strip()
    except Exception:
        pass
    return DEFAULT_MANIFEST_URL

def parse_version(value):
    pieces = str(value).strip().lstrip("v").split(".")
    numbers = []
    for piece in pieces:
        digits = ""
        for character in piece:
            if character.isdigit():
                digits += character
            else:
                break
        numbers.append(int(digits or 0))
    while len(numbers) < 3:
        numbers.append(0)
    return tuple(numbers[:3])

def check_update_status():
    local = installed_version()
    try:
        request_object = urllib.request.Request(
            get_manifest_url(),
            headers={"User-Agent": "JordanHomeMetarMapDashboard/1.1.4"},
        )
        with urllib.request.urlopen(request_object, timeout=10) as response:
            manifest = json.loads(response.read(256000).decode("utf-8"))
        remote = str(manifest.get("version", "")).strip()
        if not remote:
            raise RuntimeError("The hosted manifest does not contain a version number.")
        local_parsed = parse_version(local)
        remote_parsed = parse_version(remote)
        if local_parsed == remote_parsed:
            return {"ok": True, "status": "up_to_date", "message": f"Up to date. Installed version: {local}."}
        if remote_parsed < local_parsed:
            return {"ok": True, "status": "hosted_release_older", "message": f"This map is newer than the hosted release. Installed version: {local}. Hosted version: {remote}."}
        return {"ok": True, "status": "update_available", "message": f"Update available. Installed version: {local}. Available version: {remote}."}
    except Exception as error:
        return {"ok": False, "status": "error", "message": f"Unable to check for updates: {error}"}

def start_update_install():
    time.sleep(1)
    run(["systemctl", "--no-block", "start", "metar-map-updater.service"], timeout=10)

def is_admin():
    return session.get("admin") is True

def admin_required(function):
    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        if not is_admin():
            return redirect(url_for("admin_login", next=request.path))
        return function(*args, **kwargs)
    return wrapped

def navigation(active="", admin=False):
    items = [("public", "/", "Map Status")]
    if admin:
        items += [
            ("admin", "/admin", "Admin"),
            ("settings", "/settings", "Map Settings"),
            ("aviation", "/aviation", "Aviation Helper"),
            ("wifi", "/wifi", "Wi-Fi"),
            ("logout", "/admin/logout", "Log Out"),
        ]
    else:
        items += [("login", "/admin/login", "Admin Login")]
    return "".join(
        f'<a class="{"active" if key == active else ""}" href="{url}">{label}</a>'
        for key, url, label in items
    )

def page(title, content, active="", admin=False):
    return f"""<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title>{STYLE}</head>
<body><header><h1>METAR Map Dashboard <span class="badge">v1.1.5</span></h1></header>
<nav>{navigation(active, admin)}</nav><main>{content}</main></body></html>"""

@app.get("/")
def public_status():
    status = read_json(STATUS, {})
    content = f"""
<div class="card">
<h2>METAR Map Status</h2>
<div class="grid">
<div class="stat"><b>Software version</b>{esc(status.get("version", installed_version()))}</div>
<div class="stat"><b>Weather API</b>{esc(status.get("diagnostic_state", "Unknown"))}</div>
<div class="stat"><b>Last weather update</b>{esc(age_text(status.get("last_success_epoch")))}</div>
<div class="stat"><b>Display mode</b>{esc(status.get("mode_label", "Unknown"))}</div>
</div>
<p class="small">Administrative controls and private tools require a login.</p>
<a class="button" href="/admin/login">Admin Login</a>
</div>"""
    return page("METAR Map", content, active="public", admin=is_admin())

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if is_admin():
        return redirect("/admin")
    message = ""
    if request.method == "POST":
        supplied = request.form.get("password", "")
        if hmac.compare_digest(supplied, ADMIN_PASSWORD):
            session["admin"] = True
            return redirect(request.args.get("next") or "/admin")
        message = '<div class="error">Incorrect password.</div>'
    content = f"""
<div class="card login-card">
<h2>Admin Login</h2>
{message}
<form method="post">
<label>Password</label>
<input name="password" type="password" autofocus required>
<button type="submit">Log In</button>
</form>
</div>"""
    return page("Admin Login", content, active="login", admin=False)

@app.get("/admin/logout")
def admin_logout():
    session.clear()
    return redirect("/")

@app.get("/admin")
@admin_required
def admin_dashboard():
    status = read_json(STATUS, {})
    error_html = f'<div class="error"><b>Last error:</b> {esc(status.get("last_error"))}</div>' if status.get("last_error") else ""
    content = f"""
<div class="card">
<h2>Admin Dashboard</h2>
<div class="grid">
<div class="stat"><b>Software version</b>{esc(status.get("version", installed_version()))}</div>
<div class="stat"><b>Configured LEDs</b>{esc(status.get("led_count", "?"))}</div>
<div class="stat"><b>Wi-Fi</b>{"Connected" if wifi_connected() else "Not connected"}</div>
<div class="stat"><b>Setup hotspot</b>{"Active" if hotspot_active() else "Off"}</div>
<div class="stat"><b>Weather API</b>{esc(status.get("diagnostic_state", "Unknown"))}</div>
<div class="stat"><b>Last weather update</b>{esc(age_text(status.get("last_success_epoch")))}</div>
<div class="stat"><b>Display mode</b>{esc(status.get("mode_label", "Unknown"))}</div>
<div class="stat"><b>Brightness</b>{esc(status.get("brightness_percent", "?"))}%</div>
</div>
{error_html}
</div>
<div class="card">
<h2>Controls</h2>
<div class="actions">
<form method="post" action="/action/refresh"><button>Refresh Weather</button></form>
<form method="post" action="/action/test"><button>Test LEDs</button></form>
<button type="button" onclick="checkUpdates()">Check for Updates</button>
<button type="button" class="warning" onclick="installUpdate()">Install Update Now</button>
<form method="post" action="/action/restart"><button class="warning">Restart Map Software</button></form>
<form method="post" action="/action/hotspot"><button class="warning">Start Wi-Fi Setup Mode</button></form>
<form method="post" action="/action/reboot"><button class="danger">Restart Device</button></form>
</div>
<div id="update-result" class="small" style="margin:10px 4px"></div>
</div>
<script>
async function checkUpdates(){{
 const box=document.getElementById('update-result');box.textContent='Checking for updates...';
 try{{const response=await fetch('/api/check-update',{{method:'POST'}});const data=await response.json();box.textContent=data.message;}}
 catch(error){{box.textContent='Unable to check for updates: '+error;}}
}}
async function installUpdate(){{
 if(!confirm('Install the newest available update now? The map will reboot after a successful installation.'))return;
 const box=document.getElementById('update-result');box.textContent='Starting update check...';
 try{{const response=await fetch('/api/install-update',{{method:'POST'}});const data=await response.json();box.textContent=data.message;}}
 catch(error){{box.textContent='Unable to start update: '+error;}}
}}
</script>"""
    return page("Admin Dashboard", content, active="admin", admin=True)

@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    config = read_json(CONFIG, {})
    led = config.get("led", {})
    old_count = max(1, min(300, int(led.get("count", 22))))
    airports = (config.get("airports", []) + [None] * old_count)[:old_count]
    notice = ""

    if request.method == "POST":
        new_count = max(1, min(300, int(request.form.get("led_count", old_count))))
        airports = [
            request.form.get(f"airport_{position}", "").strip().upper() or None
            for position in range(1, min(old_count, new_count) + 1)
        ]
        if new_count > len(airports):
            airports.extend([None] * (new_count - len(airports)))

        config["airports"] = airports[:new_count]
        config["default_mode"] = request.form.get("default_mode", "category")
        led["count"] = new_count
        led["day_brightness_percent"] = int(request.form.get("day", 32))
        led["night_brightness_percent"] = int(request.form.get("night", 8))
        led["night_start"] = request.form.get("start", "22:00")
        led["night_end"] = request.form.get("end", "07:00")
        diagnostic = int(request.form.get("diagnostic", 2))
        led["diagnostic_position"] = diagnostic if 0 <= diagnostic <= new_count else 0
        config["led"] = led
        atomic_write(CONFIG, config)

        if new_count != old_count:
            threading.Thread(target=lambda: (time.sleep(1), run(["systemctl", "restart", "metar-map.service"])), daemon=True).start()
            notice = '<div class="notice">Settings saved. The map service is restarting to apply the LED-count change.</div>'
        else:
            send_command("reload_config")
            notice = '<div class="notice">Settings saved.</div>'

        old_count = new_count
        airports = config["airports"]

    diagnostic = int(led.get("diagnostic_position", 2))
    rows = "".join(
        f"""<tr><td>{position}</td>
<td><input name="airport_{position}" value="{esc(airports[position - 1] or "")}" maxlength="5" onfocus="previewLed({position})" oninput="previewLed({position})"></td>
<td>{"Diagnostic LED" if position == diagnostic else ""}</td>
<td><button type="button" class="secondary" onclick="previewLed({position})">Light LED</button></td></tr>"""
        for position in range(1, old_count + 1)
    )
    mode_options = "".join(
        f'<option value="{mode}" {"selected" if config.get("default_mode") == mode else ""}>{label}</option>'
        for mode, label in [("category", "Flight Category"), ("ceiling", "Cloud Base"), ("wind", "Wind Speed")]
    )
    diagnostic_options = '<option value="0">Disabled</option>' + "".join(
        f'<option value="{position}" {"selected" if position == diagnostic else ""}>LED {position}</option>'
        for position in range(1, old_count + 1)
    )
    content = f"""
<div class="card">
<h2>Map Settings</h2>{notice}
<form method="post">
<div class="grid">
<div><label>Number of LEDs</label><input type="number" min="1" max="300" name="led_count" value="{old_count}"></div>
<div><label>Default mode</label><select name="default_mode">{mode_options}</select></div>
<div><label>Diagnostic LED</label><select name="diagnostic">{diagnostic_options}</select></div>
<div><label>Day brightness %</label><input type="number" min="0" max="100" name="day" value="{esc(led.get("day_brightness_percent", 32))}"></div>
<div><label>Night brightness %</label><input type="number" min="0" max="100" name="night" value="{esc(led.get("night_brightness_percent", 8))}"></div>
<div><label>Night starts</label><input type="time" name="start" value="{esc(led.get("night_start", "22:00"))}"></div>
<div><label>Night ends</label><input type="time" name="end" value="{esc(led.get("night_end", "07:00"))}"></div>
</div>
<h3>Airport Assignments</h3>
<p class="small">Selecting or typing in a field lights the matching physical LED white. Leave a field blank to keep the LED off.</p>
<table><tr><th>LED</th><th>Airport code</th><th>Reserved</th><th>Preview</th></tr>{rows}</table>
<button type="submit">Save Settings</button>
<button type="button" class="secondary" onclick="testLeds()">Test All LEDs</button>
</form>
</div>
<script>
function previewLed(position){{fetch('/api/preview-led/'+position,{{method:'POST'}});}}
function testLeds(){{fetch('/api/test-leds',{{method:'POST'}});}}
</script>"""
    return page("Map Settings", content, active="settings", admin=True)


@app.get("/aviation")
@admin_required
def aviation_landing():
    content = """
<div class="card">
<h2>Aviation Helper</h2>
<p>Select the calculator that matches the flight operation.</p>
</div>
<div class="grid">
<div class="card">
<h3>Custom W&amp;B and Calculations</h3>
<p>Use the built-in local tools for a generic aircraft or a custom calculation.</p>
<p class="small">Includes crosswind components, pressure altitude, density-altitude estimate, fuel endurance, range, time-speed-distance, and a weight-and-balance scratchpad.</p>
<a class="button" href="/aviation/custom">Open Custom Calculations</a>
</div>
<div class="card">
<h3>BSU C172 @ KEWB</h3>
<p>Open the Bridgewater State University Cessna 172R/S TOLD-card workflow for New Bedford Regional Airport.</p>
<p class="small">This option opens the exact externally hosted toldcard.com calculator. Internet access is required.</p>
<a class="button" href="/aviation/bsu">Open BSU Tool</a>
</div>
</div>
<div class="card">
<div class="warning-box"><b>Training and planning aid only.</b> Verify every result against current weather, the specific aircraft POH/AFM, approved performance data, dispatch or school procedures, and applicable operating limitations before flight.</div>
</div>
"""
    return page("Aviation Helper", content, active="aviation", admin=True)

@app.get("/aviation/bsu")
@admin_required
def aviation_bsu():
    content = """
<div class="card">
<h2>BSU C172 @ KEWB</h2>
<div class="warning-box"><b>External calculator.</b> This opens the exact toldcard.com Cessna 172R/S takeoff-and-landing-data calculator. Confirm the selected tail number, runway, weather, and final results before flight.</div>
<p>The calculator defaults to KEWB and provides BSU-oriented Cessna 172R/S aircraft selections, runway choices, METAR-derived pressure altitude and density altitude, weight-and-balance output, and takeoff-and-landing performance data.</p>
<a class="button" href="https://toldcard.com/?airport=KEWB" target="_blank" rel="noopener noreferrer">Launch toldcard.com</a>
<a class="button secondary" href="https://github.com/jackc7/toldcard.com" target="_blank" rel="noopener noreferrer">View MIT-Licensed Source</a>
<a class="button secondary" href="/aviation">Back to Aviation Helper</a>
</div>
<div class="card">
<h3>Local Source Clone</h3>
<p class="small">The updater attempts to keep a read-only reference clone at <code>/opt/metar-map/vendor/toldcard.com</code>. The exact live site remains externally hosted because the public repository depends on deployment-specific configuration and an AVWX API token that are not included in the public clone.</p>
</div>
"""
    return page("BSU C172 @ KEWB", content, active="aviation", admin=True)


@app.get("/aviation/custom")
@admin_required
def aviation_custom():
    content = """
<div class="card">
<h2>Custom Aviation Calculations</h2>
<div class="warning-box"><b>Training and planning aid only.</b> Verify all calculations against the aircraft POH/AFM, approved performance data, current weather, and applicable operating limitations before flight.</div>
</div>

<div class="card">
<h3>Crosswind and Headwind Components</h3>
<div class="inline-grid">
<div><label>Runway heading (°)</label><input id="cw-runway" type="number" value="180"></div>
<div><label>Wind direction (°)</label><input id="cw-direction" type="number" value="220"></div>
<div><label>Wind speed (kt)</label><input id="cw-speed" type="number" value="15"></div>
<div><label>Gust speed (kt, optional)</label><input id="cw-gust" type="number"></div>
</div>
<button onclick="crosswind()">Calculate</button>
<div id="cw-output" class="calc-output"></div>
</div>

<div class="card">
<h3>Pressure Altitude and Density-Altitude Estimate</h3>
<div class="inline-grid">
<div><label>Field elevation (ft)</label><input id="da-elevation" type="number" value="100"></div>
<div><label>Altimeter setting (inHg)</label><input id="da-altimeter" type="number" step="0.01" value="29.92"></div>
<div><label>Outside air temperature (°C)</label><input id="da-temp" type="number" value="20"></div>
</div>
<button onclick="densityAltitude()">Calculate</button>
<div id="da-output" class="calc-output"></div>
</div>

<div class="card">
<h3>Fuel Endurance and Range</h3>
<div class="inline-grid">
<div><label>Usable fuel (gal)</label><input id="fuel-usable" type="number" step="0.1" value="40"></div>
<div><label>Fuel burn (gal/hr)</label><input id="fuel-burn" type="number" step="0.1" value="8"></div>
<div><label>Reserve fuel (gal)</label><input id="fuel-reserve" type="number" step="0.1" value="8"></div>
<div><label>Groundspeed (kt, optional)</label><input id="fuel-gs" type="number" step="0.1" value="100"></div>
</div>
<button onclick="fuel()">Calculate</button>
<div id="fuel-output" class="calc-output"></div>
</div>

<div class="card">
<h3>Time, Speed, Distance</h3>
<p class="small">Enter any two fields and leave the field to calculate blank.</p>
<div class="inline-grid">
<div><label>Distance (NM)</label><input id="tsd-distance" type="number" step="0.1"></div>
<div><label>Groundspeed (kt)</label><input id="tsd-speed" type="number" step="0.1"></div>
<div><label>Time (minutes)</label><input id="tsd-time" type="number" step="0.1"></div>
</div>
<button onclick="tsd()">Calculate</button>
<div id="tsd-output" class="calc-output"></div>
</div>

<div class="card">
<h3>Weight-and-Balance Scratchpad</h3>
<div class="warning-box">Use aircraft-specific arms and compare the final weight and CG against the approved POH/AFM envelope. This scratchpad does not determine whether a loading condition is legal or safe.</div>
<table id="wb-table">
<thead><tr><th>Item</th><th>Weight (lb)</th><th>Arm (in)</th><th>Moment (lb-in)</th><th></th></tr></thead>
<tbody></tbody>
</table>
<button onclick="addRow()">Add Item</button>
<button class="secondary" onclick="resetWB()">Reset</button>
<div id="wb-output" class="calc-output"></div>
</div>

<script>
const number=(id)=>Number(document.getElementById(id).value);
const fixed=(value,digits=1)=>Number.isFinite(value)?value.toFixed(digits):'—';
function crosswind(){
 const runway=number('cw-runway'),direction=number('cw-direction'),speed=number('cw-speed'),gust=number('cw-gust');
 let angle=((direction-runway+540)%360)-180;
 const radians=angle*Math.PI/180;
 const cross=speed*Math.sin(radians),head=speed*Math.cos(radians);
 const side=cross<0?'left':'right';
 const longitudinal=head>=0?'headwind':'tailwind';
 let text=`Wind angle: ${fixed(Math.abs(angle),0)}°. Crosswind: ${fixed(Math.abs(cross))} kt from the ${side}. ${longitudinal}: ${fixed(Math.abs(head))} kt.`;
 if(gust>0){const gustCross=gust*Math.sin(radians);text+=` Gust crosswind: ${fixed(Math.abs(gustCross))} kt.`;}
 document.getElementById('cw-output').textContent=text;
}
function densityAltitude(){
 const elevation=number('da-elevation'),altimeter=number('da-altimeter'),temp=number('da-temp');
 const pa=elevation+(29.92-altimeter)*1000;
 const isa=15-2*(pa/1000);
 const da=pa+120*(temp-isa);
 document.getElementById('da-output').textContent=`Pressure altitude: ${fixed(pa,0)} ft. ISA temperature at pressure altitude: ${fixed(isa)} °C. Estimated density altitude: ${fixed(da,0)} ft.`;
}
function fuel(){
 const usable=number('fuel-usable'),burn=number('fuel-burn'),reserve=number('fuel-reserve'),gs=number('fuel-gs');
 if(!(burn>0)){document.getElementById('fuel-output').textContent='Fuel burn must be greater than zero.';return;}
 const available=Math.max(0,usable-reserve),hours=available/burn,minutes=hours*60;
 let text=`Usable fuel after reserve: ${fixed(available)} gal. Endurance after reserve: ${fixed(hours,2)} hr (${fixed(minutes,0)} min).`;
 if(gs>0)text+=` Estimated still-air range at entered groundspeed: ${fixed(hours*gs,0)} NM.`;
 document.getElementById('fuel-output').textContent=text;
}
function tsd(){
 const d=number('tsd-distance'),s=number('tsd-speed'),m=number('tsd-time');
 let text='Enter exactly two values and leave the value to calculate blank.';
 const hasD=d>0,hasS=s>0,hasM=m>0;
 if(hasD&&hasS&&!hasM)text=`Time: ${fixed((d/s)*60,1)} minutes.`;
 else if(hasD&&!hasS&&hasM)text=`Groundspeed: ${fixed(d/(m/60),1)} kt.`;
 else if(!hasD&&hasS&&hasM)text=`Distance: ${fixed(s*(m/60),1)} NM.`;
 document.getElementById('tsd-output').textContent=text;
}
function addRow(item='',weight='',arm=''){
 const tbody=document.querySelector('#wb-table tbody');
 const row=document.createElement('tr');
 row.innerHTML=`<td><input value="${item}" placeholder="Item"></td><td><input type="number" step="0.1" value="${weight}" oninput="updateWB()"></td><td><input type="number" step="0.1" value="${arm}" oninput="updateWB()"></td><td class="moment">0.0</td><td><button class="danger" onclick="this.closest('tr').remove();updateWB()">Remove</button></td>`;
 tbody.appendChild(row);updateWB();
}
function updateWB(){
 let totalWeight=0,totalMoment=0;
 document.querySelectorAll('#wb-table tbody tr').forEach(row=>{
  const inputs=row.querySelectorAll('input');const weight=Number(inputs[1].value)||0;const arm=Number(inputs[2].value)||0;const moment=weight*arm;
  row.querySelector('.moment').textContent=fixed(moment,1);totalWeight+=weight;totalMoment+=moment;
 });
 const cg=totalWeight>0?totalMoment/totalWeight:0;
 document.getElementById('wb-output').textContent=`Total weight: ${fixed(totalWeight,1)} lb. Total moment: ${fixed(totalMoment,1)} lb-in. Calculated CG: ${fixed(cg,2)} in.`;
}
function resetWB(){
 document.querySelector('#wb-table tbody').innerHTML='';
 addRow('Basic empty weight');addRow('Pilot / front seats');addRow('Rear seats');addRow('Fuel');addRow('Baggage');
}
resetWB();
</script>
"""
    return page("Aviation Helper", content, active="aviation", admin=True)

@app.get("/wifi")
def wifi_page():
    if not hotspot_active() and not is_admin():
        return redirect("/admin/login?next=/wifi")
    buttons = "".join(
        f'<button type="button" class="network" onclick="pick({json.dumps(ssid)})">{esc(ssid)}</button>'
        for ssid in list_networks()
    )
    content = f"""
<div class="card">
<h2>Wi-Fi Setup</h2>
<p>Select a nearby network or type its exact name.</p>
<div>{buttons or '<p class="small">Nearby networks could not be listed. Type the network name manually.</p>'}</div>
<form method="post" action="/connect">
<label>Wi-Fi name</label><input id="ssid" name="ssid" required>
<label>Password</label><input name="password" type="password">
<button>Connect</button>
</form>
<p class="small">Setup-mode address: http://{esc(HOTSPOT_IP)}</p>
</div>
<script>function pick(name){{document.getElementById('ssid').value=name;}}</script>"""
    return page("Wi-Fi Setup", content, active="wifi", admin=is_admin())

@app.post("/connect")
def connect_route():
    if not hotspot_active() and not is_admin():
        return redirect("/admin/login?next=/wifi")
    ssid = request.form.get("ssid", "").strip()
    password = request.form.get("password", "")
    if ssid:
        threading.Thread(target=connect_worker, args=(ssid, password), daemon=True).start()
    return redirect("/wifi")

@app.post("/api/preview-led/<int:position>")
@admin_required
def preview_led(position):
    send_command("preview_led", led=position)
    return jsonify(ok=True)

@app.post("/api/test-leds")
@admin_required
def test_leds():
    send_command("test_leds")
    return jsonify(ok=True)

@app.post("/api/check-update")
@admin_required
def api_check_update():
    return jsonify(check_update_status())

@app.post("/api/install-update")
@admin_required
def api_install_update():
    status = check_update_status()
    if status.get("status") != "update_available":
        return jsonify(status)
    threading.Thread(target=start_update_install, daemon=True).start()
    return jsonify(
        ok=True,
        status="install_started",
        message="Update installation started. The map will reboot automatically after a successful installation. Reopen this page after restart.",
    )

@app.post("/action/<action>")
@admin_required
def action_route(action):
    if action == "refresh":
        send_command("refresh_weather")
    elif action == "test":
        send_command("test_leds")
    elif action == "restart":
        run(["systemctl", "restart", "metar-map.service"])
    elif action == "hotspot":
        run(["nmcli", "connection", "up", HOTSPOT_CONNECTION])
    elif action == "reboot":
        threading.Thread(target=lambda: (time.sleep(1), run(["systemctl", "reboot"])), daemon=True).start()
    return redirect("/admin")

@app.route("/generate_204")
@app.route("/hotspot-detect.html")
@app.route("/ncsi.txt")
@app.route("/connecttest.txt")
def captive_probe():
    return redirect("/wifi" if hotspot_active() else "/")

@app.route("/<path:path>")
def fallback(path):
    return redirect("/wifi" if hotspot_active() else "/")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
