#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/metar-map"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Update installer must run as root."
    exit 1
fi

if [[ ! -x "${INSTALL_DIR}/venv/bin/python" ]]; then
    echo "Existing METAR map installation not found."
    exit 1
fi

mkdir -p "${INSTALL_DIR}/update-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="${INSTALL_DIR}/update-backups/${STAMP}"
mkdir -p "${BACKUP_DIR}"

for FILE in metar_map.py wifi_portal.py config.json VERSION; do
    if [[ -f "${INSTALL_DIR}/${FILE}" ]]; then
        cp "${INSTALL_DIR}/${FILE}" "${BACKUP_DIR}/${FILE}"
    fi
done

cp "${SCRIPT_DIR}/metar_map.py" "${INSTALL_DIR}/metar_map.py"
cp "${SCRIPT_DIR}/wifi_portal.py" "${INSTALL_DIR}/wifi_portal.py"
chmod 644 "${INSTALL_DIR}/metar_map.py" "${INSTALL_DIR}/wifi_portal.py"

if [[ ! -f "${INSTALL_DIR}/config.json" ]]; then
    cp "${SCRIPT_DIR}/config.default.json" "${INSTALL_DIR}/config.json"
fi

"${INSTALL_DIR}/venv/bin/python" -m py_compile "${INSTALL_DIR}/metar_map.py"
"${INSTALL_DIR}/venv/bin/python" -m py_compile "${INSTALL_DIR}/wifi_portal.py"

systemctl restart metar-wifi-portal.service
systemctl restart metar-map.service
