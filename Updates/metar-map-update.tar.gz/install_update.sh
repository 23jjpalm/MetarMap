#!/usr/bin/env bash
set -euo pipefail

INSTALL_DIR="/opt/metar-map"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Update installer must run as root."
    exit 1
fi

if [[ ! -x "${INSTALL_DIR}/venv/bin/python" ]]; then
    echo "Existing METAR map installation not found."
    exit 1
fi

mkdir -p "${INSTALL_DIR}/update-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="${INSTALL_DIR}/update-backups/${STAMP}"
mkdir -p "${BACKUP_DIR}"

for FILE in metar_map.py wifi_portal.py config.json VERSION; do
    if [[ -f "${INSTALL_DIR}/${FILE}" ]]; then
        cp "${INSTALL_DIR}/${FILE}" "${BACKUP_DIR}/${FILE}"
    fi
done

cp "${SCRIPT_DIR}/metar_map.py" "${INSTALL_DIR}/metar_map.py"
cp "${SCRIPT_DIR}/wifi_portal.py" "${INSTALL_DIR}/wifi_portal.py"
chmod 644 "${INSTALL_DIR}/metar_map.py" "${INSTALL_DIR}/wifi_portal.py"

if [[ ! -f "${INSTALL_DIR}/config.json" ]]; then
    cp "${SCRIPT_DIR}/config.default.json" "${INSTALL_DIR}/config.json"
    chmod 644 "${INSTALL_DIR}/config.json"
fi

if [[ ! -f /etc/metar-map-dashboard.conf ]]; then
    SECRET="$(python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)"
    cat > /etc/metar-map-dashboard.conf <<EOF
ADMIN_PASSWORD=palmieri
FLASK_SECRET_KEY=${SECRET}
EOF
    chmod 600 /etc/metar-map-dashboard.conf
fi

mkdir -p /etc/systemd/system/metar-wifi-portal.service.d
cat > /etc/systemd/system/metar-wifi-portal.service.d/admin.conf <<'EOF'
[Service]
EnvironmentFile=-/etc/metar-map-dashboard.conf
EOF

"${INSTALL_DIR}/venv/bin/python" -m py_compile "${INSTALL_DIR}/metar_map.py"
"${INSTALL_DIR}/venv/bin/python" -m py_compile "${INSTALL_DIR}/wifi_portal.py"


# Install source attribution for the local offline BSU fork.
mkdir -p /opt/metar-map/vendor
cat > /opt/metar-map/vendor/toldcard.com-LICENSE.txt <<'EOF'
MIT License

Copyright (c) 2023 toldcard.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

systemctl daemon-reload
systemctl restart metar-wifi-portal.service
systemctl restart metar-map.service
