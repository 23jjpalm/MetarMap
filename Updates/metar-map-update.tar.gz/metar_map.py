#!/usr/bin/env python3
import json, os, re, subprocess, threading, time
from datetime import datetime
from pathlib import Path
import requests
from gpiozero import Button
from rpi_ws281x import PixelStrip, Color

BASE=Path('/opt/metar-map'); CONFIG=BASE/'config.json'; STATUS=BASE/'status.json'; COMMAND=BASE/'command.json'; VERSION=BASE/'VERSION'
URL='https://aviationweather.gov/api/data/metar'; HEADERS={'User-Agent':'JordanHomeMetarMap/1.1'}
MODES=['category','ceiling','wind']; LABELS={'category':'FLIGHT CATEGORY','ceiling':'CLOUD BASE','wind':'WIND SPEED'}
COLORS={'OFF':(0,0,0),'GREEN':(0,255,0),'BLUE':(0,0,255),'YELLOW':(255,170,0),'RED':(255,0,0),'PINK':(255,0,120),'PURPLE':(150,0,255),'WHITE':(255,255,255)}
lock=threading.RLock(); stop=threading.Event(); refresh=threading.Event()
config={}; reports={}; mode_index=0; strip=None; override_until=0.0; last_success=None; last_error=''; diag_state='booting'

def atomic(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_text(json.dumps(data,indent=2)+'\n'); os.replace(tmp,path)

def load_config():
    global config, mode_index
    config=json.loads(CONFIG.read_text())
    led=config['led']; n=int(led['count']); config['airports']=(config.get('airports',[])+[None]*n)[:n]
    mode_index=MODES.index(config.get('default_mode','category')) if config.get('default_mode','category') in MODES else 0

def version(): return VERSION.read_text().strip() if VERSION.exists() else 'unknown'
def run(cmd): return subprocess.run(cmd,capture_output=True,text=True,check=False,timeout=10)
def hotspot():
    try: return 'metar-map-setup' in run(['nmcli','-t','-f','NAME','connection','show','--active']).stdout.splitlines()
    except Exception: return False

def brightness():
    led=config['led']; now=datetime.now().hour*60+datetime.now().minute
    sh,sm=map(int,led['night_start'].split(':')); eh,em=map(int,led['night_end'].split(':')); s=sh*60+sm; e=eh*60+em
    night=(s<=now<e) if s<e else (now>=s or now<e) if s!=e else False
    return int(led['night_brightness_percent'] if night else led['day_brightness_percent'])

def px(pos,name):
    r,g,b=COLORS.get(name,COLORS['OFF']); strip.setPixelColor(pos-1,Color(r,g,b))
def show(): strip.setBrightness(round(255*brightness()/100)); strip.show()
def clear():
    with lock:
        for i in range(1,strip.numPixels()+1): px(i,'OFF')
        show()

def parse_vis(r):
    try:
        if r.get('visib') is not None: return float(str(r['visib']).replace('+',''))
    except ValueError: pass
    m=re.search(r'\b(P|M)?(?:(\d+)\s+)?(\d+/\d+|\d+(?:\.\d+)?)SM\b',r.get('rawOb',''))
    if not m:return None
    v=float(m.group(2) or 0); part=m.group(3); v+=float(part.split('/')[0])/float(part.split('/')[1]) if '/' in part else float(part)
    return v-.01 if m.group(1)=='M' else v

def ceiling(r):
    vals=[]
    for c in r.get('clouds',[]):
        if str(c.get('cover','')).upper() in {'BKN','OVC','VV','OVX'} and c.get('base') is not None:
            try: vals.append(int(c['base']))
            except Exception: pass
    if vals:return min(vals)
    raw=re.findall(r'\b(?:BKN|OVC|VV|OVX)(\d{3})\b',r.get('rawOb','')); return min(int(x)*100 for x in raw) if raw else None

def wind(r):
    try: ws=int(float(r['wspd'])) if r.get('wspd') is not None else None
    except Exception: ws=None
    try: wg=int(float(r['wgst'])) if r.get('wgst') is not None else None
    except Exception: wg=None
    if ws is not None:return ws,wg
    m=re.search(r'\b(?:\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?KT\b',r.get('rawOb',''))
    return (int(m.group(1)),int(m.group(2)) if m.group(2) else None) if m else (None,None)

def category(r):
    api=str(r.get('fltCat','')).upper()
    if api in {'VFR','MVFR','IFR','LIFR'}: return api
    v=parse_vis(r); c=ceiling(r)
    if v is None:return 'UNKNOWN'
    if v<1 or (c is not None and c<500):return 'LIFR'
    if v<3 or (c is not None and c<1000):return 'IFR'
    if v<=5 or (c is not None and c<=3000):return 'MVFR'
    return 'VFR'

def display_color(r,mode):
    if mode=='category': return {'VFR':'GREEN','MVFR':'BLUE','IFR':'RED','LIFR':'PINK'}.get(category(r),'OFF')
    if mode=='ceiling':
        c=ceiling(r)
        if c is None:return 'GREEN'
        if c<500:return 'PINK'
        if c<=1000:return 'RED'
        if c<=3000:return 'YELLOW'
        if c<=5000:return 'BLUE'
        return 'GREEN'
    ws,_=wind(r)
    if ws is None:return 'OFF'
    return 'GREEN' if ws<10 else 'BLUE' if ws<20 else 'YELLOW' if ws<30 else 'RED'

def status_write():
    atomic(STATUS,{'version':version(),'mode':MODES[mode_index],'mode_label':LABELS[MODES[mode_index]],'diagnostic_state':diag_state,'diagnostic_led_position':config['led']['diagnostic_position'],'led_count':int(config['led']['count']),'brightness_percent':brightness(),'last_success_epoch':last_success,'last_error':last_error,'report_count':len(reports),'hotspot_active':hotspot(),'updated_epoch':time.time()})

def render():
    if time.monotonic()<override_until:return
    with lock:
        diag=int(config['led'].get('diagnostic_position',0)); mode=MODES[mode_index]
        for pos,airport in enumerate(config['airports'],1):
            if pos==diag: continue
            px(pos,'OFF' if not airport or airport not in reports else display_color(reports[airport],mode))
        show()
    status_write()

def cycle():
    global mode_index
    mode_index=(mode_index+1)%len(MODES); render()

def report_lookup(items):
    out={}
    for r in items:
        code=str(r.get('icaoId','')).upper()
        if code: out[code]=r
    return out

def weather_loop():
    global reports,last_success,last_error,diag_state
    while not stop.is_set():
        try:
            diag=int(config['led'].get('diagnostic_position',0)); ids=[a for p,a in enumerate(config['airports'],1) if a and p!=diag]
            res=requests.get(URL,params={'ids':','.join(ids),'format':'json'},headers=HEADERS,timeout=15); res.raise_for_status()
            reports=report_lookup(res.json()); last_success=time.time(); last_error=''; diag_state='healthy' if reports else 'no_data'; render()
        except Exception as e:
            last_error=str(e); diag_state='weather_error'; status_write()
        refresh.clear(); refresh.wait(timeout=max(15,int(config.get('weather_refresh_seconds',60))))

def diag_loop():
    while not stop.is_set():
        try:
            pos=int(config['led'].get('diagnostic_position',0))
            if pos and time.monotonic()>=override_until:
                phase=int(time.monotonic()*2)%2
                name='PURPLE' if hotspot() and phase else 'BLUE' if diag_state=='booting' and phase else 'RED' if diag_state=='weather_error' and phase else 'YELLOW' if diag_state=='no_data' and phase else 'GREEN' if diag_state=='healthy' and int(time.monotonic()*2)%10==0 else 'OFF'
                with lock: px(pos,name); show()
        except Exception: pass
        stop.wait(.5)

def command_loop():
    global override_until
    while not stop.is_set():
        if COMMAND.exists():
            try: cmd=json.loads(COMMAND.read_text()); COMMAND.unlink(missing_ok=True); action=cmd.get('action')
            except Exception: action=''
            if action=='preview_led':
                pos=int(cmd.get('led',0)); override_until=time.monotonic()+4
                with lock:
                    for i in range(1,strip.numPixels()+1): px(i,'OFF')
                    if 1<=pos<=strip.numPixels(): px(pos,'WHITE')
                    show()
            elif action=='test_leds':
                override_until=time.monotonic()+strip.numPixels()*.18+1
                for pos in range(1,strip.numPixels()+1):
                    with lock:
                        for i in range(1,strip.numPixels()+1): px(i,'OFF')
                        px(pos,'WHITE'); show()
                    time.sleep(.18)
                render()
            elif action=='refresh_weather': refresh.set()
            elif action=='reload_config':
                old_count=strip.numPixels()
                load_config()
                if int(config['led']['count'])!=old_count:
                    subprocess.run(['systemctl','restart','metar-map.service'],check=False)
                    return
                render()
        if time.monotonic()>=override_until: render()
        stop.wait(1)

def main():
    global strip
    load_config(); led=config['led']; strip=PixelStrip(int(led['count']),int(led['gpio']),int(led['freq_hz']),int(led['dma']),bool(led['invert']),255,int(led['channel'])); strip.begin()
    Button(int(config['button_gpio']),pull_up=True,bounce_time=.25).when_pressed=cycle
    with lock:
        for i in range(1,strip.numPixels()+1): px(i,'WHITE')
        show(); time.sleep(.5)
    clear()
    for fn in (weather_loop,diag_loop,command_loop): threading.Thread(target=fn,daemon=True).start()
    try:
        while True: time.sleep(1)
    finally: stop.set(); clear()
if __name__=='__main__': main()
